/**
 * header accordion 설정 jq_ui
 */
$(function() {
	$("#accordion").accordion({
		collapsible: true,
		active: 10
		/*disable:true,*/
		/*event: "mouseover"*/
	});
});